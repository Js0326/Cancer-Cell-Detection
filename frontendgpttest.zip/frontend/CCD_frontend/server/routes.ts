import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";
import fs from "fs";
import { storage } from "./storage";
import { insertUserSchema, insertAnalysisSchema } from "@shared/schema";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
import express from "express";
import session from "express-session";
import MemoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";

// Configure multer for image uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const uploadDir = path.join(__dirname, 'uploads');
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      const ext = path.extname(file.originalname);
      cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
  }),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB max file size
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.jpg', '.jpeg', '.png', '.tiff'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Only JPG, PNG and TIFF formats are allowed'));
    }
  }
});

// Model simulation function (replace with actual ONNX model implementation)
async function classifyImage(imagePath: string): Promise<{isMalignant: boolean, malignantProbability: number, benignProbability: number, findings: string}> {
  // In a real implementation, this would use the ONNX model
  // Simulating model processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // Generate probabilities with random bias towards malignant for demo
  const malignantProb = Math.floor(Math.random() * 100);
  const benignProb = 100 - malignantProb;
  const isMalignant = malignantProb > 50;
  
  const findings = isMalignant 
    ? "Image analysis indicates presence of abnormal cell structures consistent with invasive ductal carcinoma. Cells show irregular nuclei and disrupted tissue architecture."
    : "Analysis shows normal cell structures with regular nuclei and organized tissue architecture consistent with benign breast tissue.";
  
  return {
    isMalignant,
    malignantProbability: malignantProb,
    benignProbability: benignProb,
    findings
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Configure session middleware
  const MemoryStoreSession = MemoryStore(session);
  app.use(session({
    secret: process.env.SESSION_SECRET || 'celldetect-secret-key',
    resave: false,
    saveUninitialized: false,
    store: new MemoryStoreSession({
      checkPeriod: 86400000 // prune expired entries every 24h
    }),
    cookie: { 
      secure: process.env.NODE_ENV === 'production',
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Configure passport
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(new LocalStrategy(async (username, password, done) => {
    try {
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return done(null, false, { message: 'Incorrect username' });
      }
      
      const isValid = await bcrypt.compare(password, user.password);
      if (!isValid) {
        return done(null, false, { message: 'Incorrect password' });
      }
      
      return done(null, user);
    } catch (err) {
      return done(err);
    }
  }));

  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (err) {
      done(err);
    }
  });

  // Create static directories for uploads if they don't exist
  const uploadDir = path.join(__dirname, 'uploads');
  if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
  }
  
  // Serve uploaded images
  app.use('/api/uploads', express.static(uploadDir));
  
  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.isAuthenticated()) {
      return next();
    }
    res.status(401).json({ message: 'Not authenticated' });
  };
  
  // Authentication routes
  app.post('/api/auth/register', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: 'Username already exists' });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user with hashed password
      const newUser = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors });
      } else {
        res.status(500).json({ message: 'Internal server error' });
      }
    }
  });
  
  app.post('/api/auth/login', passport.authenticate('local'), (req: Request, res: Response) => {
    const { password, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });
  
  app.post('/api/auth/logout', (req: Request, res: Response) => {
    req.logout(() => {
      res.json({ message: 'Logged out successfully' });
    });
  });
  
  app.get('/api/auth/user', (req: Request, res: Response) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    const { password, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });
  
  // Analysis routes
  app.post('/api/analyses/upload', isAuthenticated, upload.single('image'), async (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No image uploaded' });
      }
      
      const user = req.user as any;
      const imagePath = req.file.path;
      const imageUrl = `/api/uploads/${path.basename(imagePath)}`;
      
      // Perform image classification
      const result = await classifyImage(imagePath);
      
      // Create analysis record
      const analysis = await storage.createAnalysis({
        userId: user.id,
        imageUrl,
        malignantProbability: result.malignantProbability,
        benignProbability: result.benignProbability,
        findings: result.findings,
        isMalignant: result.isMalignant
      });
      
      res.status(201).json(analysis);
    } catch (error) {
      res.status(500).json({ message: error instanceof Error ? error.message : 'Internal server error' });
    }
  });
  
  app.get('/api/analyses', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const user = req.user as any;
      const analyses = await storage.getAnalyses(user.id);
      res.json(analyses);
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  app.get('/api/analyses/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const analysis = await storage.getAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: 'Analysis not found' });
      }
      
      const user = req.user as any;
      if (analysis.userId !== user.id) {
        return res.status(403).json({ message: 'Unauthorized access' });
      }
      
      res.json(analysis);
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  app.delete('/api/analyses/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid ID format' });
      }
      
      const analysis = await storage.getAnalysis(id);
      if (!analysis) {
        return res.status(404).json({ message: 'Analysis not found' });
      }
      
      const user = req.user as any;
      if (analysis.userId !== user.id) {
        return res.status(403).json({ message: 'Unauthorized access' });
      }
      
      const success = await storage.deleteAnalysis(id);
      if (success) {
        res.json({ message: 'Analysis deleted successfully' });
      } else {
        res.status(500).json({ message: 'Failed to delete analysis' });
      }
    } catch (error) {
      res.status(500).json({ message: 'Internal server error' });
    }
  });
  
  // Model info route
  app.get('/api/model/info', async (req: Request, res: Response) => {
    res.json({
      name: 'Swin Transformer',
      accuracy: 96.8,
      pathologistAccuracy: 91.2,
      dataset: 'BreaKHis_v1',
      benignSamples: 2480,
      malignantSamples: 5429,
      magnificationLevels: 4
    });
  });

  return httpServer;
}
