import * as ort from "onnxruntime-web";
import { apiRequest } from "@/lib/queryClient";
import { processImage } from "@/utils/imageUtils";

// Service for handling model inference
export interface AnalysisResult {
  id: number;
  imageUrl: string;
  malignantProbability: number;
  benignProbability: number;
  findings: string;
  isMalignant: boolean;
  createdAt: string;
}

export interface ModelMetrics {
  name: string;
  accuracy: number;
  pathologistAccuracy: number;
  dataset: string;
  benignSamples: number;
  malignantSamples: number;
  magnificationLevels: number;
}

// Get model info from API
export const getModelInfo = async (): Promise<ModelMetrics> => {
  try {
    const response = await fetch('/api/model/info', {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch model info');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching model info:', error);
    throw error;
  }
};

// Analyze image using backend API
export const analyzeImage = async (imageFile: File): Promise<AnalysisResult> => {
  try {
    const formData = new FormData();
    formData.append('image', imageFile);
    
    const response = await fetch('/api/analyses/upload', {
      method: 'POST',
      body: formData,
      credentials: 'include',
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to analyze image');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error analyzing image:', error);
    throw error;
  }
};

// Get user's analysis history
export const getAnalysisHistory = async (): Promise<AnalysisResult[]> => {
  try {
    const response = await fetch('/api/analyses', {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch analysis history');
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching analysis history:', error);
    throw error;
  }
};

// Client-side inference using ONNX Runtime Web (for demo purposes)
// In production, the actual model would be served from the backend
export const runClientInference = async (imageFile: File): Promise<{
  malignantProbability: number;
  benignProbability: number;
  isMalignant: boolean;
}> => {
  try {
    // Process image to the required format (224x224 tensor)
    const imageTensor = await processImage(imageFile);
    
    // Load ONNX model
    // Note: In a real implementation, we would use a pre-trained Swin Transformer model
    // converted to ONNX format
    console.log('Loading ONNX model...');
    const session = await ort.InferenceSession.create('/models/swin_transformer.onnx');
    
    // Run inference
    console.log('Running inference...');
    const feeds: Record<string, ort.Tensor> = {};
    feeds['input'] = imageTensor;
    
    const outputMap = await session.run(feeds);
    const output = outputMap['output'].data as Float32Array;
    
    // Process results (binary classification: benign vs malignant)
    const malignantProbability = Math.round(output[1] * 100);
    const benignProbability = Math.round(output[0] * 100);
    const isMalignant = malignantProbability > benignProbability;
    
    return {
      malignantProbability,
      benignProbability,
      isMalignant
    };
  } catch (error) {
    console.error('Error running client-side inference:', error);
    throw error;
  }
};

// Get specific analysis by ID
export const getAnalysisById = async (id: number): Promise<AnalysisResult> => {
  try {
    const response = await fetch(`/api/analyses/${id}`, {
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Failed to fetch analysis');
    }
    
    return await response.json();
  } catch (error) {
    console.error(`Error fetching analysis ID ${id}:`, error);
    throw error;
  }
};

// Delete analysis by ID
export const deleteAnalysis = async (id: number): Promise<void> => {
  try {
    const response = await fetch(`/api/analyses/${id}`, {
      method: 'DELETE',
      credentials: 'include',
    });
    
    if (!response.ok) {
      throw new Error('Failed to delete analysis');
    }
  } catch (error) {
    console.error(`Error deleting analysis ID ${id}:`, error);
    throw error;
  }
};
