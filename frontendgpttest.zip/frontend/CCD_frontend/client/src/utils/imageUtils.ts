import * as ort from 'onnxruntime-web';

// Function to load an image and convert it to an HTMLImageElement
export const loadImage = (file: File): Promise<HTMLImageElement> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const img = new Image();
      
      img.onload = () => {
        resolve(img);
      };
      
      img.onerror = () => {
        reject(new Error('Failed to load image'));
      };
      
      img.src = e.target?.result as string;
    };
    
    reader.onerror = () => {
      reject(new Error('Failed to read file'));
    };
    
    reader.readAsDataURL(file);
  });
};

// Function to preprocess image for the ONNX model
export const processImage = async (file: File): Promise<ort.Tensor> => {
  // Load image
  const img = await loadImage(file);
  
  // Create canvas and resize image to 224x224 (standard input size for many models)
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Set canvas dimensions
  canvas.width = 224;
  canvas.height = 224;
  
  // Draw and resize image to canvas
  ctx.drawImage(img, 0, 0, 224, 224);
  
  // Get image data
  const imageData = ctx.getImageData(0, 0, 224, 224).data;
  
  // Preprocess image: normalize to [0, 1] and then standardize with mean/std values
  // Standard ImageNet normalization: mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
  const tensor = new Float32Array(3 * 224 * 224);
  const mean = [0.485, 0.456, 0.406];
  const std = [0.229, 0.224, 0.225];
  
  // NCHW format (batch, channels, height, width)
  // Process each pixel
  for (let y = 0; y < 224; y++) {
    for (let x = 0; x < 224; x++) {
      const idx = (y * 224 + x) * 4; // RGBA format from canvas
      
      // Extract RGB values
      const r = imageData[idx] / 255;
      const g = imageData[idx + 1] / 255;
      const b = imageData[idx + 2] / 255;
      
      // Normalize with ImageNet mean and std
      tensor[0 * 224 * 224 + y * 224 + x] = (r - mean[0]) / std[0];
      tensor[1 * 224 * 224 + y * 224 + x] = (g - mean[1]) / std[1];
      tensor[2 * 224 * 224 + y * 224 + x] = (b - mean[2]) / std[2];
    }
  }
  
  // Create ONNX tensor
  return new ort.Tensor('float32', tensor, [1, 3, 224, 224]);
};

// Function to apply image augmentation techniques (for training purposes)
export const augmentImage = async (file: File): Promise<File> => {
  // Load image
  const img = await loadImage(file);
  
  // Create canvas
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  // Set canvas to image dimensions
  canvas.width = img.width;
  canvas.height = img.height;
  
  // Apply random transformations
  ctx.save();
  
  // Random rotation (+/- 10 degrees)
  const rotation = (Math.random() - 0.5) * 20 * Math.PI / 180;
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(rotation);
  ctx.translate(-canvas.width / 2, -canvas.height / 2);
  
  // Random horizontal flip
  if (Math.random() > 0.5) {
    ctx.scale(-1, 1);
    ctx.translate(-canvas.width, 0);
  }
  
  // Draw image with transformations
  ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
  
  // Random brightness/contrast adjustments
  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;
  
  // Brightness adjustment
  const brightnessAdjust = (Math.random() - 0.5) * 50;
  
  // Contrast adjustment (1.0 is normal)
  const contrastAdjust = Math.random() * 0.4 + 0.8;
  
  // Apply adjustments
  const factor = 259 * (contrastAdjust + 255) / (255 * (259 - contrastAdjust));
  
  for (let i = 0; i < data.length; i += 4) {
    // Brightness
    data[i] += brightnessAdjust;
    data[i + 1] += brightnessAdjust;
    data[i + 2] += brightnessAdjust;
    
    // Contrast
    data[i] = factor * (data[i] - 128) + 128;
    data[i + 1] = factor * (data[i + 1] - 128) + 128;
    data[i + 2] = factor * (data[i + 2] - 128) + 128;
  }
  
  ctx.putImageData(imageData, 0, 0);
  ctx.restore();
  
  // Convert canvas to Blob
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => {
      if (!blob) {
        reject(new Error('Failed to create Blob'));
        return;
      }
      
      // Create File object from Blob
      const augmentedFile = new File([blob], file.name, {
        type: file.type,
        lastModified: Date.now()
      });
      
      resolve(augmentedFile);
    }, file.type);
  });
};

// Function to create a thumbnail from an image file
export const createThumbnail = async (file: File, maxWidth: number = 100, maxHeight: number = 100): Promise<string> => {
  // Load image
  const img = await loadImage(file);
  
  // Calculate thumbnail dimensions (maintaining aspect ratio)
  let width = img.width;
  let height = img.height;
  
  if (width > height) {
    if (width > maxWidth) {
      height = Math.round(height * maxWidth / width);
      width = maxWidth;
    }
  } else {
    if (height > maxHeight) {
      width = Math.round(width * maxHeight / height);
      height = maxHeight;
    }
  }
  
  // Create canvas and resize image
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  
  if (!ctx) {
    throw new Error('Failed to get canvas context');
  }
  
  canvas.width = width;
  canvas.height = height;
  
  // Draw resized image to canvas
  ctx.drawImage(img, 0, 0, width, height);
  
  // Return data URL
  return canvas.toDataURL(file.type);
};

// Function to extract metadata from an image file
export const extractImageMetadata = async (file: File): Promise<{
  width: number;
  height: number;
  type: string;
  size: number;
}> => {
  // Load image
  const img = await loadImage(file);
  
  return {
    width: img.width,
    height: img.height,
    type: file.type,
    size: file.size
  };
};

// Function to check if an image meets the requirements for analysis
export const validateImageForAnalysis = async (file: File): Promise<{
  valid: boolean;
  message?: string;
}> => {
  // Check file type
  const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/tiff'];
  if (!validTypes.includes(file.type)) {
    return {
      valid: false,
      message: 'Invalid file type. Please upload a JPG, PNG, or TIFF file.'
    };
  }
  
  // Check file size (max 10MB)
  const maxSize = 10 * 1024 * 1024;
  if (file.size > maxSize) {
    return {
      valid: false,
      message: 'File too large. Maximum size is 10MB.'
    };
  }
  
  try {
    // Load image and check dimensions
    const img = await loadImage(file);
    
    // Check if image is too small
    if (img.width < 100 || img.height < 100) {
      return {
        valid: false,
        message: 'Image dimensions too small. Minimum size is 100x100 pixels.'
      };
    }
    
    return { valid: true };
  } catch (error) {
    return {
      valid: false,
      message: 'Failed to load image. The file may be corrupted.'
    };
  }
};
