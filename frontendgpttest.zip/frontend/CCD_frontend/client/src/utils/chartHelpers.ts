import { Chart, ChartConfiguration, ChartData, ChartDataset, ChartType } from 'chart.js';
import { AnalysisResult } from '@/lib/modelService';

// Default chart colors
export const chartColors = {
  primary: 'rgb(59, 130, 246)',
  primaryTransparent: 'rgba(59, 130, 246, 0.1)',
  secondary: 'rgb(16, 185, 129)',
  secondaryTransparent: 'rgba(16, 185, 129, 0.1)',
  tertiary: 'rgb(249, 115, 22)',
  tertiaryTransparent: 'rgba(249, 115, 22, 0.1)',
  red: 'rgb(239, 68, 68)',
  redTransparent: 'rgba(239, 68, 68, 0.1)',
  green: 'rgb(34, 197, 94)',
  greenTransparent: 'rgba(34, 197, 94, 0.1)',
  // Shade variants for pie charts
  primaryShades: [
    'rgba(59, 130, 246, 0.9)',
    'rgba(59, 130, 246, 0.75)',
    'rgba(59, 130, 246, 0.6)',
    'rgba(59, 130, 246, 0.45)',
    'rgba(59, 130, 246, 0.3)'
  ]
};

// Function to create performance line chart
export const createPerformanceChart = (
  ctx: CanvasRenderingContext2D | null,
  labels: string[],
  accuracyData: number[],
  precisionData: number[],
  recallData: number[]
): Chart | null => {
  if (!ctx) return null;
  
  const data: ChartData = {
    labels,
    datasets: [
      {
        label: 'Accuracy',
        data: accuracyData,
        borderColor: chartColors.primary,
        backgroundColor: chartColors.primaryTransparent,
        tension: 0.3,
        fill: true,
      },
      {
        label: 'Precision',
        data: precisionData,
        borderColor: chartColors.secondary,
        backgroundColor: chartColors.secondaryTransparent,
        tension: 0.3,
      },
      {
        label: 'Recall',
        data: recallData,
        borderColor: chartColors.tertiary,
        backgroundColor: chartColors.tertiaryTransparent,
        tension: 0.3,
      }
    ]
  };
  
  const config: ChartConfiguration = {
    type: 'line' as ChartType,
    data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 20,
            usePointStyle: true,
            boxWidth: 6
          }
        },
        tooltip: {
          mode: 'index',
          intersect: false,
        }
      },
      scales: {
        y: {
          min: 85,
          max: 100,
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        }
      },
      elements: {
        point: {
          radius: 3,
          hoverRadius: 5
        }
      }
    }
  };
  
  return new Chart(ctx, config);
};

// Function to create confidence distribution pie chart
export const createConfidenceDistributionChart = (
  ctx: CanvasRenderingContext2D | null,
  analyses: AnalysisResult[]
): Chart | null => {
  if (!ctx || !analyses || analyses.length === 0) return null;
  
  // Calculate confidence distribution
  const confidenceCounts = {
    '90-100': 0,
    '80-90': 0,
    '70-80': 0, 
    '60-70': 0,
    '<60': 0
  };
  
  analyses.forEach(analysis => {
    const confidence = analysis.isMalignant ? 
      analysis.malignantProbability : 
      analysis.benignProbability;
    
    if (confidence >= 90) confidenceCounts['90-100']++;
    else if (confidence >= 80) confidenceCounts['80-90']++;
    else if (confidence >= 70) confidenceCounts['70-80']++;
    else if (confidence >= 60) confidenceCounts['60-70']++;
    else confidenceCounts['<60']++;
  });
  
  const data: ChartData = {
    labels: Object.keys(confidenceCounts),
    datasets: [{
      data: Object.values(confidenceCounts),
      backgroundColor: chartColors.primaryShades,
      borderColor: 'rgba(255, 255, 255, 0.5)',
      borderWidth: 1
    }]
  };
  
  const config: ChartConfiguration = {
    type: 'pie' as ChartType,
    data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            padding: 15,
            usePointStyle: true,
            boxWidth: 6
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              const value = context.raw as number;
              const percent = Math.round((value / analyses.length) * 100);
              return `${context.label}: ${value} (${percent}%)`;
            }
          }
        }
      }
    }
  };
  
  return new Chart(ctx, config);
};

// Function to create classification results bar chart
export const createClassificationResultsChart = (
  ctx: CanvasRenderingContext2D | null,
  malignantProbability: number,
  benignProbability: number
): Chart | null => {
  if (!ctx) return null;
  
  const data: ChartData = {
    labels: ['Classification Result'],
    datasets: [
      {
        label: 'Malignant',
        data: [malignantProbability],
        backgroundColor: chartColors.red,
        barPercentage: 0.7,
        categoryPercentage: 0.8,
      },
      {
        label: 'Benign',
        data: [benignProbability],
        backgroundColor: chartColors.green,
        barPercentage: 0.7,
        categoryPercentage: 0.8,
      }
    ]
  };
  
  const config: ChartConfiguration = {
    type: 'bar' as ChartType,
    data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      indexAxis: 'y',
      plugins: {
        legend: {
          position: 'bottom',
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `${context.dataset.label}: ${context.raw}%`;
            }
          }
        }
      },
      scales: {
        x: {
          stacked: true,
          max: 100,
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        },
        y: {
          stacked: true,
        }
      }
    }
  };
  
  return new Chart(ctx, config);
};

// Helper function to calculate average confidence score from analyses
export const calculateAverageConfidence = (analyses: AnalysisResult[]): number => {
  if (!analyses || analyses.length === 0) return 0;
  
  const totalConfidence = analyses.reduce((acc, analysis) => {
    return acc + (analysis.isMalignant ? 
      analysis.malignantProbability : 
      analysis.benignProbability);
  }, 0);
  
  return Math.round(totalConfidence / analyses.length);
};

// Helper function to calculate class distribution (malignant vs benign)
export const calculateClassDistribution = (analyses: AnalysisResult[]): { 
  malignant: number; 
  benign: number; 
} => {
  if (!analyses || analyses.length === 0) {
    return { malignant: 0, benign: 0 };
  }
  
  const malignant = analyses.filter(a => a.isMalignant).length;
  return {
    malignant,
    benign: analyses.length - malignant
  };
};

// Helper function to create a timeline chart for analysis timestamps
export const createTimelineChart = (
  ctx: CanvasRenderingContext2D | null,
  analyses: AnalysisResult[]
): Chart | null => {
  if (!ctx || !analyses || analyses.length === 0) return null;
  
  // Sort analyses by date
  const sortedAnalyses = [...analyses].sort((a, b) => 
    new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
  );
  
  // Format dates and prepare data
  const labels = sortedAnalyses.map(a => {
    const date = new Date(a.createdAt);
    return `${date.getMonth() + 1}/${date.getDate()}`;
  });
  
  const malignantData = sortedAnalyses.map(a => a.malignantProbability);
  const benignData = sortedAnalyses.map(a => a.benignProbability);
  
  const data: ChartData = {
    labels,
    datasets: [
      {
        label: 'Malignant Probability',
        data: malignantData,
        borderColor: chartColors.red,
        backgroundColor: chartColors.redTransparent,
        tension: 0.3,
        fill: false,
      },
      {
        label: 'Benign Probability',
        data: benignData,
        borderColor: chartColors.green,
        backgroundColor: chartColors.greenTransparent,
        tension: 0.3,
        fill: false,
      }
    ]
  };
  
  const config: ChartConfiguration = {
    type: 'line' as ChartType,
    data,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
        },
        tooltip: {
          mode: 'index',
          intersect: false,
        }
      },
      scales: {
        y: {
          min: 0,
          max: 100,
          ticks: {
            callback: function(value) {
              return value + '%';
            }
          }
        }
      }
    }
  };
  
  return new Chart(ctx, config);
};
