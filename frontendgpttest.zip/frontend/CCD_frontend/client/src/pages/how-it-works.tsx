import { ProcessStep } from "@/components/ui/process-step";
import { Upload, Grid3X3, BarChart4, FileText } from "lucide-react";

const FeatureExtractionGrid = () => (
  <div className="max-w-xs w-full bg-neutral-100 dark:bg-dark-700 rounded-lg p-3 text-center">
    <div className="grid grid-cols-4 gap-1">
      {Array.from({ length: 16 }).map((_, i) => (
        <div 
          key={i}
          className={`${i % 2 === 0 ? 'bg-primary-200 dark:bg-primary-800/40' : 'bg-primary-300 dark:bg-primary-700/40'} rounded-sm aspect-square`}
        ></div>
      ))}
    </div>
    <p className="text-xs mt-2 text-neutral-600 dark:text-neutral-400">Shifted Windowed Attention</p>
  </div>
);

const ClassificationDisplay = () => (
  <div className="w-48 bg-white dark:bg-dark-900 rounded-lg shadow-sm p-3">
    <div className="space-y-3">
      <div>
        <div className="flex items-center justify-between text-xs">
          <span className="font-medium text-neutral-700 dark:text-neutral-300">Malignant</span>
          <span className="font-medium text-neutral-900 dark:text-white">87%</span>
        </div>
        <div className="mt-1 w-full bg-neutral-200 dark:bg-dark-700 rounded-full h-1.5">
          <div className="bg-red-500 h-1.5 rounded-full" style={{ width: '87%' }}></div>
        </div>
      </div>
      
      <div>
        <div className="flex items-center justify-between text-xs">
          <span className="font-medium text-neutral-700 dark:text-neutral-300">Benign</span>
          <span className="font-medium text-neutral-900 dark:text-white">13%</span>
        </div>
        <div className="mt-1 w-full bg-neutral-200 dark:bg-dark-700 rounded-full h-1.5">
          <div className="bg-green-500 h-1.5 rounded-full" style={{ width: '13%' }}></div>
        </div>
      </div>
    </div>
  </div>
);

const ReportDisplay = () => (
  <div className="w-48 bg-white dark:bg-dark-900 rounded-lg shadow-sm p-3">
    <div className="flex items-center justify-between mb-2">
      <h4 className="text-xs font-medium text-neutral-900 dark:text-white">Report Summary</h4>
      <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
        Malignant
      </span>
    </div>
    <div className="space-y-1">
      {Array.from({ length: 4 }).map((_, i) => (
        <div 
          key={i}
          className={`h-1.5 w-${i === 1 ? '3/4' : i === 3 ? '5/6' : 'full'} bg-neutral-200 dark:bg-dark-700 rounded`}
        ></div>
      ))}
    </div>
    <div className="mt-3 flex space-x-1">
      <div className="h-8 w-8 bg-neutral-200 dark:bg-dark-700 rounded flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-xs text-neutral-500 dark:text-neutral-400">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
          <polyline points="7 10 12 15 17 10"></polyline>
          <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
      </div>
      <div className="h-8 w-8 bg-neutral-200 dark:bg-dark-700 rounded flex items-center justify-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-xs text-neutral-500 dark:text-neutral-400">
          <path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"></path>
          <polyline points="16 6 12 2 8 6"></polyline>
          <line x1="12" y1="2" x2="12" y2="15"></line>
        </svg>
      </div>
    </div>
  </div>
);

const HowItWorksPage = () => {
  return (
    <section id="how-it-works" className="pt-24 pb-16 bg-white dark:bg-dark-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-3xl font-heading font-bold text-neutral-900 dark:text-white">How It Works</h1>
          <p className="mt-4 text-neutral-600 dark:text-neutral-300">Understanding the process from image upload to diagnosis.</p>
        </div>
        
        <div className="relative">
          {/* Process Flow Timeline */}
          <div className="hidden md:block absolute top-0 bottom-0 left-1/2 w-0.5 bg-neutral-200 dark:bg-dark-700 -translate-x-1/2"></div>
          
          <div className="space-y-12 relative">
            <ProcessStep
              number="1"
              title="Image Upload & Preprocessing"
              description="Histopathological images are uploaded and preprocessed with normalization, resizing to 224x224 pixels, and augmentation techniques."
              image={
                <img 
                  src="https://images.unsplash.com/photo-1590650046871-92c887180603?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" 
                  alt="Image preprocessing" 
                  className="h-28 w-auto rounded-lg shadow-sm object-cover"
                />
              }
            />
            
            <ProcessStep
              number="2"
              title="Feature Extraction with Swin Transformer"
              description="The Swin Transformer uses shifted window-based self-attention to capture both local features and global relationships within the image."
              reverse
              image={<FeatureExtractionGrid />}
            />
            
            <ProcessStep
              number="3"
              title="Classification & Probability Scoring"
              description="Extracted features are classified as benign or malignant with confidence scores showing the probability of each classification."
              image={<ClassificationDisplay />}
            />
            
            <ProcessStep
              number="4"
              title="Results Visualization & Report Generation"
              description="Results are presented visually with detailed findings, and a comprehensive report is generated for medical professionals."
              reverse
              image={<ReportDisplay />}
            />
          </div>
        </div>
        
        <div className="max-w-3xl mx-auto mt-16 pt-8 border-t border-neutral-200 dark:border-dark-700">
          <h2 className="text-2xl font-heading font-bold text-neutral-900 dark:text-white mb-6 text-center">
            Technical Implementation Details
          </h2>
          
          <div className="prose prose-blue max-w-none dark:prose-invert">
            <h3>Model Architecture</h3>
            <p>
              Our Swin Transformer implementation relies on a hierarchical architecture that processes image patches of varying sizes across different stages:
            </p>
            
            <ol>
              <li>
                <strong>Patch Partitioning:</strong> Input images are divided into non-overlapping patches, similar to words in NLP tasks.
              </li>
              <li>
                <strong>Linear Embedding:</strong> Patches are embedded into a feature space using a linear projection.
              </li>
              <li>
                <strong>Transformer Blocks:</strong> Multiple Swin Transformer blocks process the embedded patches, using:
                <ul>
                  <li>Window-based multi-head self-attention</li>
                  <li>Shifted window partitioning for cross-window connections</li>
                  <li>MLP layers with GELU activation</li>
                  <li>LayerNorm for regularization</li>
                </ul>
              </li>
              <li>
                <strong>Patch Merging:</strong> Hierarchical feature maps are created by merging adjacent patches, reducing resolution while increasing feature dimensions.
              </li>
              <li>
                <strong>Classification Head:</strong> Final feature representations are processed through a global average pooling layer and a fully connected layer for binary classification.
              </li>
            </ol>
            
            <h3>Optimization & Training</h3>
            <p>
              The model was trained using the following approach:
            </p>
            
            <ul>
              <li>AdamW optimizer with initial learning rate of 1e-4 and weight decay of 0.05</li>
              <li>Cosine learning rate schedule with warmup</li>
              <li>Data augmentation including random flips, rotations, color jittering, and mixup</li>
              <li>Trained for 100 epochs on 4 NVIDIA A100 GPUs</li>
              <li>Model distillation and quantization for efficient inference</li>
            </ul>
            
            <h3>ONNX Deployment</h3>
            <p>
              For efficient deployment, the trained model was:
            </p>
            
            <ul>
              <li>Converted to ONNX format for cross-platform compatibility</li>
              <li>Optimized with ONNX Runtime's graph optimizations</li>
              <li>Quantized to INT8 precision to reduce model size and improve inference speed</li>
              <li>Deployed with a batch-processing pipeline to handle concurrent requests</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksPage;
