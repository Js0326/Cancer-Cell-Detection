import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import CellAnimation from "@/components/CellAnimation";
import UploadForm from "@/components/UploadForm";
import { ArrowRight } from "lucide-react";
import { useAuth } from "@/components/auth/AuthContext";
import AuthForm from "@/components/auth/AuthForm";

const HomePage = () => {
  const { user } = useAuth();
  
  return (
    <>
      {/* Hero Section */}
      <section id="home" className="pt-24 md:pt-32 pb-16 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="lg:w-1/2 lg:pr-12">
              <h1 className="text-4xl sm:text-5xl font-heading font-bold text-neutral-900 dark:text-white mb-6 leading-tight">
                AI-Powered Cancer Cell <span className="text-primary-600 dark:text-primary-500">Detection</span>
              </h1>
              <p className="text-lg text-neutral-600 dark:text-neutral-300 mb-8">
                Upload histopathological images and get instant analysis with our advanced Swin Transformer model. Detect and classify cancer cells with high accuracy.
              </p>
              <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                <Link href="#upload">
                  <Button className="w-full sm:w-auto" size="lg">
                    Try it now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/how-it-works">
                  <Button variant="outline" className="w-full sm:w-auto" size="lg">
                    Learn more
                  </Button>
                </Link>
              </div>
            </div>
            <div className="lg:w-1/2 mt-10 lg:mt-0 flex justify-center">
              <div className="w-full max-w-md h-64 sm:h-80 md:h-96 relative rounded-xl bg-gradient-to-br from-primary-50 to-primary-100 dark:from-dark-800 dark:to-primary-900/30 shadow-lg overflow-hidden">
                {/* 3D Cell Animation */}
                <CellAnimation />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Upload Section */}
      <section id="upload" className="py-16 bg-white dark:bg-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-heading font-bold text-neutral-900 dark:text-white">Upload Histopathological Image</h2>
            <p className="mt-4 text-neutral-600 dark:text-neutral-300">
              Upload your histopathological image and our AI model will analyze it in real-time.
            </p>
            
            {!user && (
              <div className="mt-4">
                <AuthForm 
                  trigger={
                    <Button variant="link" className="text-primary-600 dark:text-primary-400">
                      Sign in to save your results
                    </Button>
                  }
                />
              </div>
            )}
          </div>

          <UploadForm />
        </div>
      </section>
    </>
  );
};

export default HomePage;
