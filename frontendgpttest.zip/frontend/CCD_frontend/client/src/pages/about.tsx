import { useQuery } from "@tanstack/react-query";
import { CustomCard } from "@/components/ui/custom-card";
import { MetricItem, DataStat } from "@/components/ui/model-metrics";
import { Brain, Database, Loader2 } from "lucide-react";

const AboutPage = () => {
  const { data: modelInfo, isLoading } = useQuery({
    queryKey: ['/api/model/info'],
    staleTime: Infinity, // This doesn't change often
  });
  
  return (
    <section id="about" className="pt-24 pb-16 bg-neutral-50 dark:bg-dark-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-3xl font-heading font-bold text-neutral-900 dark:text-white">About Our Technology</h1>
          <p className="mt-4 text-neutral-600 dark:text-neutral-300">Learn about our AI model and the dataset that powers our detection system.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {isLoading ? (
            <div className="col-span-2 flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
            </div>
          ) : (
            <>
              <CustomCard
                title="Swin Transformer Model"
                subtitle="State-of-the-art image classification"
                icon={<Brain className="text-xl text-primary-600 dark:text-primary-400" />}
              >
                <div className="mt-6">
                  <p className="text-neutral-600 dark:text-neutral-300">
                    Our system uses the Swin Transformer, a hierarchical vision transformer that computes representations with shifted windows. This approach brings greater efficiency by limiting self-attention computation to non-overlapping local windows while also allowing for cross-window connection.
                  </p>
                  
                  <div className="mt-5 border-t border-neutral-200 dark:border-dark-700 pt-5">
                    <MetricItem 
                      label="Model Accuracy" 
                      value={`${modelInfo?.accuracy}%`}
                      progress={modelInfo?.accuracy} 
                      compareLabel="Pathologist Average"
                      compareValue={`${modelInfo?.pathologistAccuracy}%`}
                      compareProgress={modelInfo?.pathologistAccuracy}
                    />
                  </div>
                </div>
              </CustomCard>
              
              <CustomCard
                title="BreaKHis_v1 Dataset"
                subtitle="Comprehensive training foundation"
                icon={<Database className="text-xl text-secondary-600 dark:text-secondary-400" />}
                iconContainerClassName="bg-secondary-100 dark:bg-secondary-900"
              >
                <div className="mt-6">
                  <p className="text-neutral-600 dark:text-neutral-300">
                    Our model was trained on the BreaKHis_v1 dataset, which contains 7,909 microscopic images of breast tumor tissue collected from 82 patients using different magnification factors (40X, 100X, 200X, and 400X).
                  </p>
                  
                  <div className="mt-5 space-y-4">
                    <DataStat 
                      icon={<span></span>}
                      value={modelInfo?.benignSamples.toLocaleString() || "2k"}
                      label="Benign Samples"
                      description="From various tissue types"
                    />
                    
                    <DataStat 
                      icon={<span></span>}
                      value={modelInfo?.malignantSamples.toLocaleString() || "5k"}
                      label="Malignant Samples"
                      description="Multiple cancer subtypes"
                    />
                    
                    <DataStat 
                      icon={<span></span>}
                      value={`${modelInfo?.magnificationLevels}x` || "4x"}
                      label="Magnification Levels"
                      description="40X, 100X, 200X, 400X"
                    />
                  </div>
                </div>
              </CustomCard>
            </>
          )}
        </div>
        
        <div className="max-w-3xl mx-auto mt-16">
          <h2 className="text-2xl font-heading font-bold text-neutral-900 dark:text-white mb-6">Understanding Cancer Detection</h2>
          
          <div className="prose prose-blue max-w-none dark:prose-invert">
            <p>
              Histopathological image analysis is a critical component in cancer diagnosis. Traditionally, pathologists manually examine tissue samples under a microscope to identify abnormal cell patterns that may indicate malignancy. This process is time-consuming and can be subject to inter-observer variability.
            </p>
            
            <h3>How Our AI Approach Differs</h3>
            
            <p>
              The Swin Transformer model we employ represents a significant advancement over traditional convolutional neural networks (CNNs) for medical image analysis:
            </p>
            
            <ul>
              <li>
                <strong>Hierarchical Feature Learning:</strong> Unlike standard vision transformers, Swin Transformer processes images in hierarchical feature maps of varying resolutions, similar to CNNs, making it more efficient for high-resolution histopathology images.
              </li>
              <li>
                <strong>Shifted Windows:</strong> The model computes self-attention within local windows and allows for cross-window connections through a shifted window approach, capturing both local details and global context.
              </li>
              <li>
                <strong>Linear Complexity:</strong> Self-attention computation is limited to each window, achieving linear computational complexity with respect to image size.
              </li>
            </ul>
            
            <h3>Advantages for Pathologists</h3>
            
            <p>
              Our AI-powered system serves as a valuable assistant to medical professionals by:
            </p>
            
            <ul>
              <li>Providing a second opinion with quantifiable confidence scores</li>
              <li>Reducing the cognitive load of analyzing numerous samples</li>
              <li>Standardizing the assessment process to minimize variability</li>
              <li>Highlighting regions of interest that may require closer expert examination</li>
            </ul>
            
            <p>
              The system is designed to augment rather than replace human expertise, creating a collaborative approach to cancer diagnosis that combines the strengths of both artificial intelligence and human judgment.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutPage;
