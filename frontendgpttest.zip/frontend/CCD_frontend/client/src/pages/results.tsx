import { useQuery } from "@tanstack/react-query";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MetricItem, MetricsGrid } from "@/components/ui/model-metrics";
import { Loader2, ChartLine, PieChart } from "lucide-react";
import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import { useAuth } from "@/components/auth/AuthContext";
import AuthForm from "@/components/auth/AuthForm";
import { formatDistanceToNow } from "date-fns";
import { Button } from "@/components/ui/button";

// Register Chart.js components
Chart.register(...registerables);

const RecentAnalysisItem = ({ analysis }: { analysis: any }) => {
  const createdAt = new Date(analysis.createdAt);
  
  return (
    <div className="p-4 hover:bg-neutral-50 dark:hover:bg-dark-700">
      <div className="flex items-center space-x-4">
        <div className="flex-shrink-0 h-14 w-14 rounded overflow-hidden">
          <img 
            src={analysis.imageUrl}
            alt="Histopathological sample" 
            className="h-full w-full object-cover"
          />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-medium text-neutral-900 dark:text-white truncate">
            Sample #{analysis.id}
          </p>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            {formatDistanceToNow(createdAt, { addSuffix: true })}
          </p>
        </div>
        <div>
          <Badge variant={analysis.isMalignant ? "destructive" : "success"}>
            {analysis.isMalignant ? "Malignant" : "Benign"}
          </Badge>
        </div>
      </div>
    </div>
  );
};

const ResultsPage = () => {
  const { user } = useAuth();
  const performanceChartRef = useRef<HTMLCanvasElement | null>(null);
  const distributionChartRef = useRef<HTMLCanvasElement | null>(null);
  const performanceChartInstance = useRef<Chart | null>(null);
  const distributionChartInstance = useRef<Chart | null>(null);
  
  const { data: analyses, isLoading } = useQuery({
    queryKey: ['/api/analyses'],
    enabled: !!user,
  });
  
  // Create charts when data is available
  useEffect(() => {
    if (!analyses || !performanceChartRef.current || !distributionChartRef.current) return;
    
    // Clean up previous charts
    if (performanceChartInstance.current) {
      performanceChartInstance.current.destroy();
    }
    
    if (distributionChartInstance.current) {
      distributionChartInstance.current.destroy();
    }
    
    // Create performance chart
    const performanceCtx = performanceChartRef.current.getContext('2d');
    if (performanceCtx) {
      performanceChartInstance.current = new Chart(performanceCtx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
          datasets: [
            {
              label: 'Accuracy',
              data: [93.2, 94.1, 95.3, 95.8, 96.2, 96.8],
              borderColor: 'rgb(59, 130, 246)',
              backgroundColor: 'rgba(59, 130, 246, 0.1)',
              tension: 0.3,
              fill: true,
            },
            {
              label: 'Precision',
              data: [91.5, 92.8, 94.1, 94.9, 95.7, 96.2],
              borderColor: 'rgb(16, 185, 129)',
              backgroundColor: 'rgba(16, 185, 129, 0.0)',
              tension: 0.3,
            },
            {
              label: 'Recall',
              data: [90.7, 91.9, 93.2, 93.8, 94.1, 94.5],
              borderColor: 'rgb(249, 115, 22)',
              backgroundColor: 'rgba(249, 115, 22, 0.0)',
              tension: 0.3,
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                padding: 20,
                usePointStyle: true,
                boxWidth: 6
              }
            },
            tooltip: {
              mode: 'index',
              intersect: false,
            }
          },
          scales: {
            y: {
              min: 85,
              max: 100,
              ticks: {
                callback: function(value) {
                  return value + '%';
                }
              }
            }
          },
          elements: {
            point: {
              radius: 3,
              hoverRadius: 5
            }
          }
        }
      });
    }
    
    // Create distribution chart
    const distributionCtx = distributionChartRef.current.getContext('2d');
    if (distributionCtx) {
      // Calculate confidence distribution from analyses
      const confidenceCounts = {
        '90-100': 0,
        '80-90': 0,
        '70-80': 0, 
        '60-70': 0,
        '<60': 0
      };
      
      analyses.forEach((analysis: any) => {
        const confidence = analysis.isMalignant ? 
          analysis.malignantProbability : 
          analysis.benignProbability;
        
        if (confidence >= 90) confidenceCounts['90-100']++;
        else if (confidence >= 80) confidenceCounts['80-90']++;
        else if (confidence >= 70) confidenceCounts['70-80']++;
        else if (confidence >= 60) confidenceCounts['60-70']++;
        else confidenceCounts['<60']++;
      });
      
      distributionChartInstance.current = new Chart(distributionCtx, {
        type: 'pie',
        data: {
          labels: Object.keys(confidenceCounts),
          datasets: [{
            data: Object.values(confidenceCounts),
            backgroundColor: [
              'rgba(59, 130, 246, 0.9)',
              'rgba(59, 130, 246, 0.75)',
              'rgba(59, 130, 246, 0.6)',
              'rgba(59, 130, 246, 0.45)',
              'rgba(59, 130, 246, 0.3)'
            ],
            borderColor: 'rgba(255, 255, 255, 0.5)',
            borderWidth: 1
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: {
                padding: 15,
                usePointStyle: true,
                boxWidth: 6
              }
            },
            tooltip: {
              callbacks: {
                label: function(context) {
                  const value = context.raw as number;
                  const percent = Math.round((value / analyses.length) * 100);
                  return `${context.label}: ${value} (${percent}%)`;
                }
              }
            }
          }
        }
      });
    }
    
    // Cleanup on unmount
    return () => {
      if (performanceChartInstance.current) {
        performanceChartInstance.current.destroy();
      }
      
      if (distributionChartInstance.current) {
        distributionChartInstance.current.destroy();
      }
    };
  }, [analyses]);
  
  return (
    <section id="results" className="pt-24 pb-16 bg-neutral-50 dark:bg-dark-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-3xl font-heading font-bold text-neutral-900 dark:text-white">Analysis Results</h1>
          <p className="mt-4 text-neutral-600 dark:text-neutral-300">Your recent analysis history and performance metrics.</p>
        </div>
        
        {!user ? (
          <div className="max-w-md mx-auto bg-white dark:bg-dark-800 rounded-lg shadow-sm p-8 text-center">
            <h2 className="text-xl font-medium text-neutral-900 dark:text-white mb-4">Sign In to View Your Results</h2>
            <p className="text-neutral-600 dark:text-neutral-300 mb-6">
              Please sign in to view your analysis history and results.
            </p>
            <AuthForm 
              trigger={<Button className="mx-auto">Sign In</Button>}
            />
          </div>
        ) : isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Main metrics */}
            <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
              <Card className="bg-white dark:bg-dark-800 shadow-sm p-6">
                <h3 className="text-lg font-medium text-neutral-900 dark:text-white">Model Performance</h3>
                <div className="mt-4 h-60 bg-neutral-100 dark:bg-dark-900 rounded-lg flex items-center justify-center">
                  <canvas ref={performanceChartRef} className="w-full h-full p-2"></canvas>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Precision</p>
                    <p className="text-xl font-semibold text-neutral-900 dark:text-white">96.2%</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Recall</p>
                    <p className="text-xl font-semibold text-neutral-900 dark:text-white">94.5%</p>
                  </div>
                </div>
              </Card>
              
              <Card className="bg-white dark:bg-dark-800 shadow-sm p-6">
                <h3 className="text-lg font-medium text-neutral-900 dark:text-white">Confidence Distribution</h3>
                <div className="mt-4 h-60 bg-neutral-100 dark:bg-dark-900 rounded-lg flex items-center justify-center">
                  {analyses && analyses.length > 0 ? (
                    <canvas ref={distributionChartRef} className="w-full h-full p-2"></canvas>
                  ) : (
                    <div className="text-center">
                      <PieChart className="text-4xl text-secondary-500 opacity-70 mx-auto mb-2" />
                      <p className="text-sm text-neutral-500 dark:text-neutral-400">
                        No data available yet
                      </p>
                    </div>
                  )}
                </div>
                <div className="mt-4 grid grid-cols-2 gap-4">
                  <div className="text-center">
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Avg. Confidence</p>
                    <p className="text-xl font-semibold text-neutral-900 dark:text-white">
                      {analyses && analyses.length > 0 
                        ? `${Math.round(analyses.reduce((acc, analysis) => 
                            acc + (analysis.isMalignant ? 
                              analysis.malignantProbability : 
                              analysis.benignProbability), 0) / analyses.length)}%`
                        : "N/A"}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">Samples</p>
                    <p className="text-xl font-semibold text-neutral-900 dark:text-white">
                      {analyses ? analyses.length : 0}
                    </p>
                  </div>
                </div>
              </Card>
            </div>
            
            {/* Recent Analyses */}
            <Card className="bg-white dark:bg-dark-800 shadow-sm divide-y divide-neutral-200 dark:divide-dark-700">
              <div className="p-6">
                <h3 className="text-lg font-medium text-neutral-900 dark:text-white">Recent Analyses</h3>
                <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">Your latest image uploads and results</p>
              </div>
              
              {analyses && analyses.length > 0 ? (
                <>
                  {analyses.slice(0, 3).map((analysis: any) => (
                    <RecentAnalysisItem key={analysis.id} analysis={analysis} />
                  ))}
                  
                  {analyses.length > 3 && (
                    <div className="p-4 text-center">
                      <Button variant="link" className="text-sm font-medium text-primary-600 dark:text-primary-400 hover:text-primary-700 dark:hover:text-primary-300">
                        View all analyses
                      </Button>
                    </div>
                  )}
                </>
              ) : (
                <div className="p-6 text-center">
                  <p className="text-neutral-500 dark:text-neutral-400 mb-4">
                    No analyses found
                  </p>
                  <Button asChild>
                    <a href="/#upload">Upload an image</a>
                  </Button>
                </div>
              )}
            </Card>
          </div>
        )}
      </div>
    </section>
  );
};

export default ResultsPage;
