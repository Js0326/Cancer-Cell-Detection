import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import ThemeToggle from "@/components/ThemeToggle";
import { useAuth } from "@/components/auth/AuthContext";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
  SheetClose,
} from "@/components/ui/sheet";
import { Menu, User } from "lucide-react";

const NavLink = ({ href, label, currentPath }: { href: string; label: string; currentPath: string }) => {
  const isActive = currentPath === href || (href !== "/" && currentPath.startsWith(href));
  const baseClasses = "inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium";
  const activeClasses = "border-primary-500 text-neutral-900 dark:text-white";
  const inactiveClasses = "border-transparent text-neutral-500 dark:text-neutral-300 hover:border-neutral-300 dark:hover:border-neutral-700 hover:text-neutral-700 dark:hover:text-white";

  return (
    <Link href={href}>
      <a className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}>
        {label}
      </a>
    </Link>
  );
};

const MobileNavLink = ({ href, label, currentPath, onClick }: { href: string; label: string; currentPath: string; onClick: () => void }) => {
  const isActive = currentPath === href || (href !== "/" && currentPath.startsWith(href));
  const baseClasses = "block pl-3 pr-4 py-2 border-l-4 text-base font-medium";
  const activeClasses = "bg-primary-50 dark:bg-dark-700 border-primary-500 text-primary-700 dark:text-white";
  const inactiveClasses = "border-transparent text-neutral-500 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-dark-700 hover:border-neutral-300 dark:hover:border-neutral-600 hover:text-neutral-700 dark:hover:text-white";

  return (
    <SheetClose asChild>
      <Link href={href}>
        <a className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`} onClick={onClick}>
          {label}
        </a>
      </Link>
    </SheetClose>
  );
};

const Navbar = () => {
  const [location] = useLocation();
  const { user, login, logout, isLoading } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav className={`bg-white dark:bg-dark-800 fixed w-full z-20 top-0 transition-all duration-200 ${isScrolled ? 'shadow-sm' : ''}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <a className="font-heading font-bold text-xl text-primary-600 dark:text-primary-500">
                  CellDetect AI
                </a>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <NavLink href="/" label="Home" currentPath={location} />
              <NavLink href="/about" label="About" currentPath={location} />
              <NavLink href="/how-it-works" label="How It Works" currentPath={location} />
              <NavLink href="/results" label="Results" currentPath={location} />
              <NavLink href="/contact" label="Contact" currentPath={location} />
            </div>
          </div>

          <div className="hidden sm:ml-6 sm:flex sm:items-center space-x-2">
            <ThemeToggle />

            {isLoading ? (
              <div className="h-8 w-8 animate-pulse rounded-full bg-neutral-200 dark:bg-dark-700"></div>
            ) : user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="rounded-full h-8 w-8 p-0">
                    <span className="sr-only">Open user menu</span>
                    <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-700">
                      <span className="text-sm font-medium leading-none text-primary-700 dark:text-primary-100">
                        {user.username.substring(0, 2).toUpperCase()}
                      </span>
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Profile</DropdownMenuItem>
                  <DropdownMenuItem>Settings</DropdownMenuItem>
                  <DropdownMenuItem onClick={logout}>Sign out</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => login({ email: "demo@example.com", password: "password" })}
                className="rounded-md"
              >
                Sign In
              </Button>
            )}
          </div>

          <div className="-mr-2 flex items-center sm:hidden">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <span className="sr-only">Open main menu</span>
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[80%] pt-16">
                <div className="pt-2 pb-3 space-y-1">
                  <MobileNavLink 
                    href="/" 
                    label="Home" 
                    currentPath={location} 
                    onClick={() => setMobileMenuOpen(false)} 
                  />
                  <MobileNavLink 
                    href="/about" 
                    label="About" 
                    currentPath={location} 
                    onClick={() => setMobileMenuOpen(false)} 
                  />
                  <MobileNavLink 
                    href="/how-it-works" 
                    label="How It Works" 
                    currentPath={location} 
                    onClick={() => setMobileMenuOpen(false)} 
                  />
                  <MobileNavLink 
                    href="/results" 
                    label="Results" 
                    currentPath={location} 
                    onClick={() => setMobileMenuOpen(false)} 
                  />
                  <MobileNavLink 
                    href="/contact" 
                    label="Contact" 
                    currentPath={location} 
                    onClick={() => setMobileMenuOpen(false)} 
                  />
                </div>

                <div className="pt-4 pb-3 border-t border-neutral-200 dark:border-dark-700">
                  <div className="flex items-center px-4">
                    <div>
                      <ThemeToggle />
                    </div>
                    {user ? (
                      <div className="ml-3">
                        <div className="flex items-center">
                          <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-700 mr-2">
                            <span className="text-sm font-medium leading-none text-primary-700 dark:text-primary-100">
                              {user.username.substring(0, 2).toUpperCase()}
                            </span>
                          </span>
                          <div>
                            <div className="text-base font-medium text-neutral-800 dark:text-neutral-200">
                              {user.username}
                            </div>
                            <SheetClose asChild>
                              <Button 
                                variant="link" 
                                className="p-0 h-auto text-sm text-neutral-500 dark:text-neutral-400"
                                onClick={logout}
                              >
                                Sign out
                              </Button>
                            </SheetClose>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <SheetClose asChild>
                        <Button 
                          variant="default"
                          size="sm" 
                          className="ml-4"
                          onClick={() => login({ email: "demo@example.com", password: "password" })}
                        >
                          Sign In
                        </Button>
                      </SheetClose>
                    )}
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;