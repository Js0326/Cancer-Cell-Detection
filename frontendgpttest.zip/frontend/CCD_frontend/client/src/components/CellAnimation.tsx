import { useEffect, useRef } from "react";
import * as THREE from "three";

const CellAnimation = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const cellRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    // Skip initialization if refs are not available
    if (!containerRef.current) return;

    // Initialize scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // Setup camera
    const camera = new THREE.PerspectiveCamera(
      75,
      containerRef.current.clientWidth / containerRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 5;
    cameraRef.current = camera;

    // Setup renderer
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true // Transparent background
    });
    renderer.setSize(
      containerRef.current.clientWidth, 
      containerRef.current.clientHeight
    );
    renderer.setClearColor(0x000000, 0); // Transparent background
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Add ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    // Add directional light
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);

    // Create cell group
    const cellGroup = new THREE.Group();
    cellRef.current = cellGroup;
    scene.add(cellGroup);

    // Create nucleus (inner sphere)
    const nucleusGeometry = new THREE.SphereGeometry(1, 32, 32);
    const nucleusMaterial = new THREE.MeshPhongMaterial({
      color: new THREE.Color("hsl(217, 91%, 60%)"),
      transparent: true,
      opacity: 0.9,
      shininess: 100
    });
    const nucleus = new THREE.Mesh(nucleusGeometry, nucleusMaterial);
    cellGroup.add(nucleus);

    // Create middle membrane layers (3 layers)
    const createMembrane = (radius: number, opacity: number, color: string) => {
      const membraneGeometry = new THREE.SphereGeometry(radius, 32, 32);
      const membraneMaterial = new THREE.MeshPhongMaterial({
        color: new THREE.Color(color),
        transparent: true,
        opacity: opacity,
        shininess: 50
      });
      return new THREE.Mesh(membraneGeometry, membraneMaterial);
    };

    // Add membrane layers
    cellGroup.add(createMembrane(1.3, 0.4, "hsl(217, 91%, 55%)"));
    cellGroup.add(createMembrane(1.6, 0.3, "hsl(217, 91%, 50%)"));
    cellGroup.add(createMembrane(1.9, 0.2, "hsl(217, 91%, 45%)"));

    // Random small spheres to represent cell features
    const addCellFeatures = () => {
      for (let i = 0; i < 20; i++) {
        const size = Math.random() * 0.15 + 0.05;
        const feature = new THREE.Mesh(
          new THREE.SphereGeometry(size, 16, 16),
          new THREE.MeshPhongMaterial({
            color: new THREE.Color(`hsl(${Math.random() * 20 + 200}, 70%, 60%)`),
            transparent: true,
            opacity: 0.7
          })
        );
        
        // Position within the cell
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        const radius = Math.random() * 0.8 + 0.8;
        
        feature.position.x = radius * Math.sin(phi) * Math.cos(theta);
        feature.position.y = radius * Math.sin(phi) * Math.sin(theta);
        feature.position.z = radius * Math.cos(phi);
        
        cellGroup.add(feature);
      }
    };
    
    addCellFeatures();

    // Animation function
    const animate = () => {
      const animationId = requestAnimationFrame(animate);

      if (cellRef.current) {
        // Rotate the cell
        cellRef.current.rotation.x += 0.002;
        cellRef.current.rotation.y += 0.003;
        
        // Slightly pulsate the cell
        const pulseFactor = 1 + Math.sin(Date.now() * 0.001) * 0.05;
        cellRef.current.scale.set(pulseFactor, pulseFactor, pulseFactor);
      }

      // Render the scene
      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }

      // Cleanup animation on unmount
      return () => {
        cancelAnimationFrame(animationId);
      };
    };

    // Start animation
    animate();

    // Handle window resize
    const handleResize = () => {
      if (
        containerRef.current &&
        rendererRef.current &&
        cameraRef.current
      ) {
        // Update camera aspect ratio
        cameraRef.current.aspect =
          containerRef.current.clientWidth / containerRef.current.clientHeight;
        cameraRef.current.updateProjectionMatrix();

        // Update renderer size
        rendererRef.current.setSize(
          containerRef.current.clientWidth,
          containerRef.current.clientHeight
        );
      }
    };

    window.addEventListener("resize", handleResize);

    // Cleanup function
    return () => {
      window.removeEventListener("resize", handleResize);
      
      if (rendererRef.current && containerRef.current) {
        containerRef.current.removeChild(rendererRef.current.domElement);
      }
      
      if (sceneRef.current) {
        // Properly dispose of geometries and materials
        sceneRef.current.traverse((object) => {
          if (object instanceof THREE.Mesh) {
            object.geometry.dispose();
            
            if (object.material instanceof THREE.Material) {
              object.material.dispose();
            } else if (Array.isArray(object.material)) {
              object.material.forEach(material => material.dispose());
            }
          }
        });
      }
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="w-full h-full absolute inset-0 flex items-center justify-center"
      aria-label="3D Cancer Cell Visualization"
    >
      <div className="absolute bottom-4 text-sm text-center text-primary-700 dark:text-primary-300 z-10">
        <p className="font-medium">Interactive 3D Cancer Cell Model</p>
        <p className="text-xs opacity-70">Powered by Three.js</p>
      </div>
    </div>
  );
};

export default CellAnimation;
