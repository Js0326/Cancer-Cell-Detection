import { Link } from "wouter";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-neutral-100 dark:bg-dark-900 border-t border-neutral-200 dark:border-dark-700">
      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
          <div className="flex items-center">
            <Link href="/">
              <a className="font-heading font-bold text-xl text-primary-600 dark:text-primary-500">
                CellDetect AI
              </a>
            </Link>
          </div>
          
          <div className="flex space-x-6">
            <Link href="/privacy">
              <a className="text-neutral-500 hover:text-neutral-600 dark:text-neutral-400 dark:hover:text-neutral-300 text-sm">
                Privacy Policy
              </a>
            </Link>
            <Link href="/terms">
              <a className="text-neutral-500 hover:text-neutral-600 dark:text-neutral-400 dark:hover:text-neutral-300 text-sm">
                Terms of Service
              </a>
            </Link>
            <Link href="/citation">
              <a className="text-neutral-500 hover:text-neutral-600 dark:text-neutral-400 dark:hover:text-neutral-300 text-sm">
                Cite Us
              </a>
            </Link>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              &copy; {currentYear} CellDetect AI. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
