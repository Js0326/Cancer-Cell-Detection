import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ConfidenceBar } from "@/components/ui/confidence-bar";
import { Download, RefreshCw, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

interface AnalysisResultsProps {
  analysis: {
    id: number;
    imageUrl: string;
    malignantProbability: number;
    benignProbability: number;
    findings: string;
    isMalignant: boolean;
    createdAt: string;
  };
  onReset?: () => void;
}

const AnalysisResults = ({ analysis, onReset }: AnalysisResultsProps) => {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  const handleSaveResults = async () => {
    setIsSaving(true);
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    
    toast({
      title: "Results Saved",
      description: "Analysis results have been saved to your history.",
    });
  };
  
  const handleDownloadReport = () => {
    const reportData = {
      id: analysis.id,
      date: new Date().toISOString(),
      classification: analysis.isMalignant ? "Malignant" : "Benign",
      confidenceScores: {
        malignant: analysis.malignantProbability,
        benign: analysis.benignProbability,
      },
      findings: analysis.findings,
    };
    
    // Create a blob with the report data
    const reportBlob = new Blob(
      [JSON.stringify(reportData, null, 2)],
      { type: "application/json" }
    );
    
    // Create a download link
    const url = URL.createObjectURL(reportBlob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `cancer-analysis-report-${analysis.id}.json`;
    document.body.appendChild(link);
    link.click();
    
    // Cleanup
    URL.revokeObjectURL(url);
    document.body.removeChild(link);
    
    toast({
      title: "Report Downloaded",
      description: "Analysis report has been downloaded to your device.",
    });
  };
  
  const createdAt = new Date(analysis.createdAt);
  
  return (
    <div className="bg-neutral-100 dark:bg-dark-800 p-6 border-t border-neutral-200 dark:border-dark-700">
      <div className="flex flex-col md:flex-row gap-6">
        <div className="md:w-1/2">
          <div className="rounded-lg overflow-hidden border border-neutral-200 dark:border-dark-700 bg-white dark:bg-dark-900">
            <img 
              src={analysis.imageUrl}
              alt="Histopathological image" 
              className="w-full h-auto object-cover"
            />
          </div>
          <div className="mt-4">
            <p className="text-sm text-neutral-500 dark:text-neutral-400">
              Uploaded {formatDistanceToNow(createdAt, { addSuffix: true })}
            </p>
          </div>
        </div>
        
        <div className="md:w-1/2">
          <div className="bg-white dark:bg-dark-900 rounded-lg border border-neutral-200 dark:border-dark-700 p-4">
            <div className="flex items-start justify-between">
              <h3 className="text-lg font-medium text-neutral-900 dark:text-white">Analysis Results</h3>
              <Badge variant={analysis.isMalignant ? "destructive" : "success"}>
                {analysis.isMalignant ? "Malignant" : "Benign"}
              </Badge>
            </div>
            
            <div className="mt-4">
              <div className="space-y-3">
                <ConfidenceBar 
                  label="Malignant" 
                  percentage={analysis.malignantProbability} 
                  color="bg-red-500" 
                />
                
                <ConfidenceBar 
                  label="Benign" 
                  percentage={analysis.benignProbability} 
                  color="bg-green-500" 
                />
              </div>
              
              <div className="mt-6">
                <h4 className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Findings:</h4>
                <p className="mt-2 text-sm text-neutral-600 dark:text-neutral-400">
                  {analysis.findings}
                </p>
              </div>
              
              <div className="mt-6 flex space-x-3">
                <Button onClick={handleSaveResults} disabled={isSaving} size="sm" className="flex items-center">
                  <Save className="w-4 h-4 mr-1" />
                  {isSaving ? "Saving..." : "Save Results"}
                </Button>
                <Button 
                  onClick={handleDownloadReport} 
                  variant="outline" 
                  size="sm"
                  className="flex items-center"
                >
                  <Download className="w-4 h-4 mr-1" />
                  Download Report
                </Button>
                
                {onReset && (
                  <Button 
                    onClick={onReset} 
                    variant="ghost" 
                    size="sm"
                    className="flex items-center ml-auto"
                  >
                    <RefreshCw className="w-4 h-4 mr-1" />
                    New Analysis
                  </Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisResults;
