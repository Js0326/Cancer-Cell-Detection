import React from "react";
import { Progress } from "@/components/ui/progress";

interface ConfidenceBarProps {
  label: string;
  percentage: number;
  color: string;
}

export const ConfidenceBar: React.FC<ConfidenceBarProps> = ({ 
  label, 
  percentage, 
  color
}) => {
  return (
    <div>
      <div className="flex items-center justify-between">
        <div className="text-sm font-medium text-neutral-700 dark:text-neutral-300">{label}</div>
        <div className="text-sm font-medium text-neutral-900 dark:text-white">{percentage}%</div>
      </div>
      <div className="mt-1 w-full bg-neutral-200 dark:bg-dark-700 rounded-full h-2">
        <div className={`${color} h-2 rounded-full`} style={{ width: `${percentage}%` }}></div>
      </div>
    </div>
  );
};
