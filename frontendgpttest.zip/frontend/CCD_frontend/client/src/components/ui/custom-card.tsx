import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface CustomCardProps {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  className?: string;
  children: React.ReactNode;
  iconContainerClassName?: string;
}

export const CustomCard = ({
  title,
  subtitle,
  icon,
  className,
  children,
  iconContainerClassName,
}: CustomCardProps) => {
  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardHeader className="pb-3">
        <div className="flex items-center">
          {icon && (
            <div className={cn("flex-shrink-0 h-12 w-12 rounded-md bg-primary-100 dark:bg-primary-900 flex items-center justify-center mr-4", iconContainerClassName)}>
              {icon}
            </div>
          )}
          <div>
            <CardTitle className="text-lg font-medium text-neutral-900 dark:text-white">
              {title}
            </CardTitle>
            {subtitle && (
              <p className="text-sm text-neutral-500 dark:text-neutral-400">{subtitle}</p>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-2">
        {children}
      </CardContent>
    </Card>
  );
};
