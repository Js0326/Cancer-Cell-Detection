import { Progress } from "@/components/ui/progress";

interface MetricItemProps {
  label: string;
  value: string | number;
  progress?: number;
  progressColor?: string;
  compareLabel?: string;
  compareValue?: string | number;
  compareProgress?: number;
  compareColor?: string;
}

export const MetricItem = ({ 
  label, 
  value, 
  progress, 
  progressColor = "bg-primary-500",
  compareLabel,
  compareValue,
  compareProgress,
  compareColor = "bg-neutral-400 dark:bg-neutral-500"
}: MetricItemProps) => {
  return (
    <div>
      {progress !== undefined && (
        <>
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-neutral-700 dark:text-neutral-300">{label}</span>
            <span className="text-primary-600 dark:text-primary-400 font-medium">{value}</span>
          </div>
          <div className="mt-1 w-full bg-neutral-200 dark:bg-dark-700 rounded-full h-2">
            <div 
              className={`${progressColor} h-2 rounded-full`} 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </>
      )}
      
      {compareProgress !== undefined && compareLabel && compareValue !== undefined && (
        <div className="mt-4">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-neutral-700 dark:text-neutral-300">{compareLabel}</span>
            <span className="text-neutral-500 dark:text-neutral-400 font-medium">{compareValue}</span>
          </div>
          <div className="mt-1 w-full bg-neutral-200 dark:bg-dark-700 rounded-full h-2">
            <div 
              className={`${compareColor} h-2 rounded-full`} 
              style={{ width: `${compareProgress}%` }}
            ></div>
          </div>
        </div>
      )}
      
      {/* If no progress, just show the value */}
      {progress === undefined && (
        <div className="text-center">
          <p className="text-sm font-medium text-neutral-500 dark:text-neutral-400">{label}</p>
          <p className="text-xl font-semibold text-neutral-900 dark:text-white">{value}</p>
        </div>
      )}
    </div>
  );
};

export const MetricsGrid = ({ children, columns = 2 }: { children: React.ReactNode; columns?: number }) => {
  return (
    <div className={`grid grid-cols-1 sm:grid-cols-${columns} gap-4`}>
      {children}
    </div>
  );
};

export const DataStat = ({ 
  icon, 
  value, 
  label, 
  description 
}: { 
  icon: React.ReactNode; 
  value: string | number; 
  label: string; 
  description?: string;
}) => {
  return (
    <div className="flex items-center">
      <div className="flex-shrink-0 h-10 w-10 rounded-md bg-neutral-100 dark:bg-dark-700 flex items-center justify-center">
        {typeof value === 'string' ? (
          <span className="text-sm font-medium text-neutral-700 dark:text-neutral-300">{value}</span>
        ) : (
          icon
        )}
      </div>
      <div className="ml-4">
        <h4 className="text-sm font-medium text-neutral-700 dark:text-neutral-300">{label}</h4>
        {description && (
          <p className="text-xs text-neutral-500 dark:text-neutral-400">{description}</p>
        )}
      </div>
    </div>
  );
};
