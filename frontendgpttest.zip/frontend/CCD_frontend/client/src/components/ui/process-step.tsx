import React from "react";
import { cn } from "@/lib/utils";

interface ProcessStepProps {
  number: number | string;
  title: string;
  description: string;
  image?: React.ReactNode;
  reverse?: boolean;
  className?: string;
}

export const ProcessStep = ({
  number,
  title,
  description,
  image,
  reverse = false,
  className,
}: ProcessStepProps) => {
  return (
    <div className={cn("relative", className)}>
      <div className={`flex flex-col ${reverse ? 'md:flex-row-reverse' : 'md:flex-row'} items-center`}>
        <div className={`flex-1 ${reverse ? 'md:pl-8' : 'md:text-right md:pr-8'}`}>
          <div className="bg-white dark:bg-dark-800 p-4 rounded-lg shadow-sm inline-block">
            <h3 className="text-lg font-medium text-neutral-900 dark:text-white">{title}</h3>
            <p className="mt-2 text-neutral-600 dark:text-neutral-300">
              {description}
            </p>
          </div>
        </div>
        
        <div className="md:mx-auto flex items-center justify-center w-12 h-12 rounded-full bg-primary-100 dark:bg-primary-900 border-4 border-white dark:border-dark-800 my-4 md:my-0 z-10">
          <span className="font-heading font-bold text-primary-600 dark:text-primary-400">{number}</span>
        </div>
        
        <div className={`flex-1 ${reverse ? 'md:pr-8' : 'md:pl-8'}`}>
          <div className="md:h-36 flex items-center justify-center">
            {image}
          </div>
        </div>
      </div>
    </div>
  );
};
