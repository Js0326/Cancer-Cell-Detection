import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileWarning } from "lucide-react";
import { useAuth } from "@/components/auth/AuthContext";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import AnalysisResults from "@/components/AnalysisResults";
import { Progress } from "@/components/ui/progress";

const UploadForm = () => {
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;
    
    // Take the first file
    const file = acceptedFiles[0];
    
    // Check file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/tiff'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload a JPG, PNG, or TIFF file.",
        variant: "destructive"
      });
      return;
    }
    
    // Check file size
    const maxSize = 10 * 1024 * 1024; // 10 MB
    if (file.size > maxSize) {
      toast({
        title: "File too large",
        description: "Maximum file size is 10MB.",
        variant: "destructive"
      });
      return;
    }
    
    setUploadedFile(file);
    setAnalysisResult(null);
  }, [toast]);
  
  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/tiff': ['.tiff'],
    },
    maxFiles: 1,
    multiple: false
  });
  
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      setIsUploading(true);
      setUploadProgress(0);
      
      const formData = new FormData();
      formData.append('image', file);
      
      try {
        const xhr = new XMLHttpRequest();
        const promise = new Promise<any>((resolve, reject) => {
          xhr.open('POST', '/api/analyses/upload');
          xhr.withCredentials = true;
          
          xhr.upload.onprogress = (event) => {
            if (event.lengthComputable) {
              const progress = Math.round((event.loaded / event.total) * 100);
              setUploadProgress(progress);
            }
          };
          
          xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              resolve(JSON.parse(xhr.responseText));
            } else {
              reject(new Error(xhr.statusText || 'Upload failed'));
            }
          };
          
          xhr.onerror = () => {
            reject(new Error('Network error during upload'));
          };
          
          xhr.send(formData);
        });
        
        setUploadProgress(100);
        await new Promise(resolve => setTimeout(resolve, 500)); // Show 100% progress briefly
        const result = await promise;
        return result;
      } finally {
        setIsUploading(false);
      }
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/analyses'] });
      setAnalysisResult(data);
      toast({
        title: "Analysis Complete",
        description: "Image has been successfully analyzed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Upload Failed",
        description: error instanceof Error ? error.message : "An error occurred during upload",
        variant: "destructive"
      });
    }
  });
  
  const handleUpload = () => {
    if (!uploadedFile) return;
    
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to analyze images.",
        variant: "destructive"
      });
      return;
    }
    
    uploadMutation.mutate(uploadedFile);
  };
  
  return (
    <div className="max-w-3xl mx-auto bg-neutral-50 dark:bg-dark-900 rounded-lg shadow-sm overflow-hidden">
      {!analysisResult && (
        <div className="p-6">
          <div
            {...getRootProps()}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
              isDragActive
                ? "border-primary-500 dark:border-primary-600"
                : "border-neutral-300 dark:border-dark-700 hover:border-primary-500 dark:hover:border-primary-600"
            }`}
          >
            <input {...getInputProps()} />
            <div className="space-y-4">
              <Upload className="h-10 w-10 mx-auto text-neutral-400 dark:text-neutral-500" />
              <div>
                <p className="text-lg font-medium text-neutral-800 dark:text-white">
                  {uploadedFile ? uploadedFile.name : "Drag & drop image here"}
                </p>
                <p className="text-neutral-500 dark:text-neutral-400 text-sm">or</p>
              </div>
              <Button type="button" className="mx-auto">
                Browse files
              </Button>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 max-w-xs mx-auto">
                Supported formats: JPG, PNG, TIFF. Maximum file size: 10MB
              </p>
            </div>
          </div>
          
          {uploadedFile && (
            <div className="mt-4">
              {isUploading ? (
                <div className="space-y-2">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-600 dark:text-neutral-400">Uploading...</span>
                    <span className="text-neutral-600 dark:text-neutral-400">{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              ) : (
                <Button 
                  onClick={handleUpload} 
                  className="w-full"
                  disabled={uploadMutation.isPending}
                >
                  {uploadMutation.isPending ? "Analyzing..." : "Analyze Image"}
                </Button>
              )}
            </div>
          )}
          
          <div className="mt-6">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium text-neutral-700 dark:text-neutral-300">Image requirements:</p>
            </div>
            <div className="mt-2 text-sm text-neutral-500 dark:text-neutral-400 space-y-2">
              <p>• Histopathological slides only</p>
              <p>• 40x or 100x magnification preferred</p>
              <p>• Clear focus with minimal artifacts</p>
              <p>• H&E stained samples recommended</p>
            </div>
          </div>
        </div>
      )}
      
      {analysisResult && (
        <AnalysisResults 
          analysis={analysisResult} 
          onReset={() => {
            setAnalysisResult(null);
            setUploadedFile(null);
          }}
        />
      )}
    </div>
  );
};

export default UploadForm;
