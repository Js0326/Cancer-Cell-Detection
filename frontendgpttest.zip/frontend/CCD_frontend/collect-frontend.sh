
#!/bin/bash

# Create main directory
mkdir -p frontend-files

# Copy client directory
cp -r client frontend-files/

# Copy configuration files
cp package.json frontend-files/
cp tsconfig.json frontend-files/
cp postcss.config.js frontend-files/
cp tailwind.config.ts frontend-files/
cp vite.config.ts frontend-files/
cp theme.json frontend-files/
cp .gitignore frontend-files/
cp drizzle.config.ts frontend-files/

# Copy shared directory (since it contains schemas used by frontend)
cp -r shared frontend-files/

# Copy assets
cp -r attached_assets frontend-files/

# Create README with dependencies info
echo "Frontend Dependencies:" > frontend-files/README.md
grep -A 50 '"dependencies":' package.json >> frontend-files/README.md
